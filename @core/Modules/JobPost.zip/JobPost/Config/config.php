<?php

return [
    'name' => 'JobPost'
];
