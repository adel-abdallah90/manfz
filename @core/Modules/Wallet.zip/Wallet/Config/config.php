<?php

return [
    'name' => 'Wallet'
];
