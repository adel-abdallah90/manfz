<?php

namespace Modules\Wallet\PageBuilder;

use App\PageBuilder;

class PageBuilderSetup extends PageBuilder\PageBuilderSetup
{
    public static function register_widgets(): array
    {
        return [
            //
        ];
    }
}